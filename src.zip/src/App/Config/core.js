let constants = new Object();

constants.BASE_URL = "http://127.0.0.1:8080";
constants.LOGIN_URL = "/login/auth";
constants.FORM_URL = "/leave/submitleave"

module.exports = constants;