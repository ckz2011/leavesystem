import React, { PureComponent } from 'react'

class ViewRequests extends PureComponent {
    constructor(props) {
        super(props)

        this.state = {
            
        }
    }

    render() {
        return (
            <p> Hello view Requests</p>
            
        )
    }
}

export default ViewRequests